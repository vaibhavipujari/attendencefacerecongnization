import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

cred = credentials.Certificate("serviceAccountKey.json")
firebase_admin.initialize_app(cred, {'databaseURL': "https://faceattendance-3bc16-default-rtdb.firebaseio.com/"})

# add data to database

ref = db.reference('Students')

data = {
    "142515":
        {
            "name": "Dhanashree Deore",
            "major": "IT",
            "starting year": 2020,
            "total_attendance": 6,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2024-01-09 00:30:22"
        },

    "123456":
        {
            "name": "Tushar Dhere",
            "major": "IT",
            "starting year": 2020,
            "total_attendance": 9,
            "standing": "G",
            "year": 4,
            "last_attendance_time": "2024-01-09 00:30:22"
        },

    "254525":
        {
            "name": "Meloni",
            "major": "Politics",
            "starting year": 2021,
            "total_attendance": 8,
            "standing": "G",
            "year": 3,
            "last_attendance_time": "2024-01-09 00:30:22"
        }
}

for key, value in data.items():
    ref.child(key).set(value)
